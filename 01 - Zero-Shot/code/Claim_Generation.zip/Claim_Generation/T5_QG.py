import itertools
import logging
from typing import Optional, Dict, Union
from nltk import sent_tokenize

import torch
from transformers import(
    AutoModelForSeq2SeqLM, 
    AutoTokenizer,
    PreTrainedModel,
    PreTrainedTokenizer,
)

logger = logging.getLogger(__name__)

class QGPipeline:
    def __init__(
        self,
        model: PreTrainedModel,
        tokenizer: PreTrainedTokenizer,
        ans_model: PreTrainedModel,
        ans_tokenizer: PreTrainedTokenizer,
        qg_format: str,
        gpu_index: int
    ):
        self.model = model
        self.tokenizer = tokenizer

        self.ans_model = ans_model
        self.ans_tokenizer = ans_tokenizer

        self.qg_format = qg_format

        # self.device = "cuda" if torch.cuda.is_available() and use_cuda else "cpu"
        self.device = torch.device('cuda:{}'.format(gpu_index))
        self.model.to(self.device)

        if self.ans_model is not self.model:
            self.ans_model.to(self.device)

        assert self.model.__class__.__name__ in ["T5ForConditionalGeneration", "BartForConditionalGeneration"]
        
        if "T5ForConditionalGeneration" in self.model.__class__.__name__:
            self.model_type = "t5"
        else:
            self.model_type = "bart"

    # Common processing
    def __call__(self, inputs: str):
        # self.source = " ".join(inputs.split())
        pass

    # Interface 0: extract answers
    def extract_answers(self, inputs: str):
        inputs = " ".join(inputs.split())
        _, answers = self._extract_answers(inputs)
        return answers

    # Interface 1: generate questions without answer
    def qg_without_answer(self, inputs: str):
        inputs = " ".join(inputs.split())
        sents, answers = self._extract_answers(inputs)
        flat_answers = list(itertools.chain(*answers))
        
        if len(flat_answers) == 0:
          return []

        if self.qg_format == "prepend":
            qg_examples = self._prepare_inputs_for_qg_from_answers_prepend(inputs, answers)
        else:
            try:
                qg_examples = self._prepare_inputs_for_qg_from_answers_hl(sents, answers)
            except Exception:
                return []
        
        qg_inputs = [example['source_text'] for example in qg_examples]
        questions = self._generate_questions(qg_inputs)
        output = [{'answer': example['answer'], 'question': que} for example, que in zip(qg_examples, questions)]
        return output

    # Interface 2: answer-aware question generation
    def qg_with_answer_text(self, inputs: str, answer_text: str):
        inputs = " ".join(inputs.split())
        sents = sent_tokenize(inputs)

        # does not support preprend yet
        qg_examples = []
        answer_text = answer_text.strip()
        sents_copy = sents[:]
        # looking for answer position
        for i, sent in enumerate(sents):
            if sent.find(answer_text)>=0:
                ans_start_idx = sent.index(answer_text)
        
                sent_tmp = f"{sent[:ans_start_idx]} <hl> {answer_text} <hl> {sent[ans_start_idx + len(answer_text): ]}"
                sents_copy[i] = sent_tmp
                break

        # generate question
        source_text = " ".join(sents_copy)
        source_text = f"generate question: {source_text}" 
        if self.model_type == "t5":
            source_text = source_text + " </s>"
        
        qg_examples.append({"answer": answer_text, "source_text": source_text})
        qg_inputs = [example['source_text'] for example in qg_examples]
        questions = self._generate_questions(qg_inputs)
        output = [{'answer': example['answer'], 'question': que} for example, que in zip(qg_examples, questions)]
        return output

    # generate a batch of examples at one time
    # Input format: 
    #   inputs: ['src1', 'src2', ...]
    #   answers: ['ans1', 'ans2', ...]
    def batch_qg_with_answer(self, inputs: list, answers: list):
        # preprocessing
        qg_examples = []
        
        for ind, source in enumerate(inputs):
            source = " ".join(source.split())
            sents = sent_tokenize(source)
            print("and here it breaks")
            answer_text = answers[ind]

            answer_text = answer_text.strip()
            sents_copy = sents[:]
            # looking for answer position
            for i, sent in enumerate(sents):
                if sent.find(answer_text)>=0:
                    ans_start_idx = sent.index(answer_text)
            
                    sent_tmp = f"{sent[:ans_start_idx]} <hl> {answer_text} <hl> {sent[ans_start_idx + len(answer_text): ]}"
                    sents_copy[i] = sent_tmp
                    break

            source_text = " ".join(sents_copy)
            source_text = f"generate question: {source_text}" 
            if self.model_type == "t5":
                source_text = source_text + " </s>"
            
            qg_examples.append({"answer": answer_text, "source_text": source_text})
        
        qg_inputs = [example['source_text'] for example in qg_examples]
        questions = self._generate_questions(qg_inputs)
        output = [{'answer': example['answer'], 'question': que} for example, que in zip(qg_examples, questions)]
        return output

    # Interface 3: answer-aware question generation with <hl> tags
    def qg_with_answer_hl(self, inputs: str):
        # extract answer text from <hl> ... <hl>
        answer_text = inputs.split('<hl>')[1]
        
        source_text = f"generate question: {inputs}" 
        if self.model_type == "t5":
            source_text = source_text + " </s>"
        
        qg_examples = []
        qg_examples.append({"answer": answer_text, "source_text": source_text})
        qg_inputs = [example['source_text'] for example in qg_examples]
        questions = self._generate_questions(qg_inputs)
        output = [{'answer': example['answer'], 'question': que} for example, que in zip(qg_examples, questions)]
        return output
    
    def _generate_questions(self, inputs):
        inputs = self._tokenize(inputs, padding=True, truncation=True)
        
        outs = self.model.generate(
            input_ids=inputs['input_ids'].to(self.device), 
            attention_mask=inputs['attention_mask'].to(self.device), 
            max_length=32,
            num_beams=4,
        )
        
        questions = [self.tokenizer.decode(ids, skip_special_tokens=True) for ids in outs]
        return questions
    
    def _extract_answers(self, context):
        sents, inputs = self._prepare_inputs_for_ans_extraction(context)
        inputs = self._tokenize(inputs, padding=True, truncation=True)

        outs = self.ans_model.generate(
            input_ids=inputs['input_ids'].to(self.device), 
            attention_mask=inputs['attention_mask'].to(self.device), 
            max_length=32,
        )
        
        dec = [self.ans_tokenizer.decode(ids, skip_special_tokens=False) for ids in outs]
        answers = [item.split('<sep>') for item in dec]
        answers = [i[:-1] for i in answers]
        
        return sents, answers
    
    def _tokenize(self,
        inputs,
        padding=True,
        truncation=True,
        add_special_tokens=True,
        max_length=512
    ):
        inputs = self.tokenizer.batch_encode_plus(
            inputs, 
            max_length=max_length,
            add_special_tokens=add_special_tokens,
            truncation=truncation,
            padding="max_length" if padding else False,
            pad_to_max_length=padding,
            return_tensors="pt"
        )
        return inputs
    
    def _prepare_inputs_for_ans_extraction(self, text):
        sents = sent_tokenize(text)

        inputs = []
        for i in range(len(sents)):
            source_text = "extract answers:"
            for j, sent in enumerate(sents):
                if i == j:
                    sent = "<hl> %s <hl>" % sent
                source_text = "%s %s" % (source_text, sent)
                source_text = source_text.strip()
            
            if self.model_type == "t5":
                source_text = source_text + " </s>"
            inputs.append(source_text)

        return sents, inputs
    
    def _prepare_inputs_for_qg_from_answers_hl(self, sents, answers):
        inputs = []
        for i, answer in enumerate(answers):
            if len(answer) == 0: continue
            sent = sents[i]
            for answer_text in answer:
                sents_copy = sents[:]
                
                answer_text = answer_text.strip()
                
                ans_start_idx = sent.index(answer_text)
                
                sent_tmp = f"{sent[:ans_start_idx]} <hl> {answer_text} <hl> {sent[ans_start_idx + len(answer_text): ]}"
                sents_copy[i] = sent_tmp
                
                source_text = " ".join(sents_copy)
                source_text = f"generate question: {source_text}" 
                if self.model_type == "t5":
                    source_text = source_text + " </s>"
                
                inputs.append({"answer": answer_text, "source_text": source_text})
        
        return inputs
    
    def _prepare_inputs_for_qg_from_answers_prepend(self, context, answers):
        flat_answers = list(itertools.chain(*answers))
        examples = []
        for answer in flat_answers:
            source_text = f"answer: {answer} context: {context}"
            if self.model_type == "t5":
                source_text = source_text + " </s>"
            
            examples.append({"answer": answer, "source_text": source_text})
        return examples

    

SUPPORTED_TASKS = {
    "question-generation": {
        "impl": QGPipeline,
        "default": {
            "model": "valhalla/t5-base-qg-hl",
            "ans_model": "valhalla/t5-base-qa-qg-hl",
        }
    }
}

def pipeline(
    task: str,
    model: Optional[str] = None,
    tokenizer: Optional[Union[str, PreTrainedTokenizer]] = None,
    qg_format: Optional[str] = "highlight",
    ans_model: Optional[str] = None,
    ans_tokenizer: Optional[Union[str, PreTrainedTokenizer]] = None,
    gpu_index: Optional[int] = 0,
    **kwargs,
):
    # Retrieve the task
    if task not in SUPPORTED_TASKS:
        raise KeyError("Unknown task {}, available tasks are {}".format(task, list(SUPPORTED_TASKS.keys())))

    targeted_task = SUPPORTED_TASKS[task]
    task_class = targeted_task["impl"]

    # Use default model/config/tokenizer for the task if no model is provided
    if model is None:
        model = targeted_task["default"]["model"]
    
    # Try to infer tokenizer from model or config name (if provided as str)
    if tokenizer is None:
        if isinstance(model, str):
            tokenizer = model
        else:
            # Impossible to guest what is the right tokenizer here
            raise Exception(
                "Impossible to guess which tokenizer to use. "
                "Please provided a PretrainedTokenizer class or a path/identifier to a pretrained tokenizer."
            )
    
    # Instantiate tokenizer if needed
    if isinstance(tokenizer, (str, tuple)):
        if isinstance(tokenizer, tuple):
            # For tuple we have (tokenizer name, {kwargs})
            tokenizer = AutoTokenizer.from_pretrained(tokenizer[0], **tokenizer[1])
        else:
            tokenizer = AutoTokenizer.from_pretrained(tokenizer)
    
    # Instantiate model if needed
    if isinstance(model, str):
        model = AutoModelForSeq2SeqLM.from_pretrained(model)
    
    if task == "question-generation":
        if ans_model is None:
            # load default ans model
            ans_model = targeted_task["default"]["ans_model"]
            ans_tokenizer = AutoTokenizer.from_pretrained(ans_model)
            ans_model = AutoModelForSeq2SeqLM.from_pretrained(ans_model)
        else:
            # Try to infer tokenizer from model or config name (if provided as str)
            if ans_tokenizer is None:
                if isinstance(ans_model, str):
                    ans_tokenizer = ans_model
                else:
                    # Impossible to guest what is the right tokenizer here
                    raise Exception(
                        "Impossible to guess which tokenizer to use. "
                        "Please provided a PretrainedTokenizer class or a path/identifier to a pretrained tokenizer."
                    )
            
            # Instantiate tokenizer if needed
            if isinstance(ans_tokenizer, (str, tuple)):
                if isinstance(ans_tokenizer, tuple):
                    # For tuple we have (tokenizer name, {kwargs})
                    ans_tokenizer = AutoTokenizer.from_pretrained(ans_tokenizer[0], **ans_tokenizer[1])
                else:
                    ans_tokenizer = AutoTokenizer.from_pretrained(ans_tokenizer)

            if isinstance(ans_model, str):
                ans_model = AutoModelForSeq2SeqLM.from_pretrained(ans_model)

        return task_class(model=model, tokenizer=tokenizer, ans_model=ans_model, ans_tokenizer=ans_tokenizer, qg_format=qg_format, gpu_index=gpu_index)
    else:
        return task_class(model=model, tokenizer=tokenizer, ans_model=model, ans_tokenizer=tokenizer, qg_format=qg_format, gpu_index=gpu_index)

# debug codes
if __name__ == "__main__":
    test_passage = '''PERSON (born 19 January 1980) is a British racing driver and former Formula One driver. 
    He won the 2009 Formula One World Championship, driving for Brawn GP.'''

    test_passage_hl = '''PERSON (born <hl> 19 January 1980 <hl> ) is a British racing driver and former Formula One driver. 
    He won the 2009 Formula One World Championship, driving for Brawn GP.'''

    nlp = pipeline("question-generation", model='valhalla/t5-base-qg-hl', qg_format="highlight", gpu_index=0)
    #print(nlp.qg_without_answer(test_passage))
    #print(nlp.qg_with_answer_text(test_passage, "19 January 1980"))
    print(nlp.qg_with_answer_hl(test_passage_hl))
